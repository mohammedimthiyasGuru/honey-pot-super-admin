export const environment = {
  production: true,
  // 34.221.117.87:3000

  // 34.211.194.144:3000

     apiUrl: 'http://mysalveo.com/api/',
     imageURL: 'http://mysalveo.com/api/'
  // apiUrl: 'http://localhost:91/'
};

